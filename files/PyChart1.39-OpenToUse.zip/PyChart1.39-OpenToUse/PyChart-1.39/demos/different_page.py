
#
# Copyright (C) 2000-2005 by Yasushi Saito (yasushi.saito@gmail.com)
# 
# Pychart is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.
#
# Pychart is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
from pychart import *
theme.get_options()

# We have 10 sample points total.  The first value in each tuple is
# the X value, and subsequent values are Y values for different lines.

data_misses = chart_data.read_str(', ',
             "4KB, 12653295, 579789",
             "64KB, 3124314, 570016",
             "2MB, 1630, 4396511",
             "64MB, 117, 14380703",
             "256MB, 37, 32494922",
             )

# The format attribute specifies the text to be drawn at each tloc=(15,75)ick mark.
# Here, texts are rotated -60 degrees ("/a-60"), left-aligned ("/hL"),
# and numbers are printed as integers ("%d"). 
xaxis = axis.X(format="/7/a-25{}%s", label="")
yaxis = axis.Y(format="/7/a-55{}%.2E", label="/8TLB Misses and Directory Evictions \n Under Difference Page Sizes", tic_interval = 100)

# Define the drawing area. "y_range=(0,None)" tells that the Y minimum
# is 0, but the Y maximum is to be computed automatically. Without
# y_ranges, Pychart will pick the minimum Y value among the samples,
# i.e., 20, as the base value of Y axis.
ar = area.T(size=(180, 100), y_coord=log_coord.T(), x_coord=category_coord.T(data_misses, 0), x_axis=xaxis, y_axis=yaxis,
            legend=legend.T(nr_rows=1, loc=(15,10)), loc=(0,0))

# The first plot extracts Y values from the 2nd column
# ("ycol=1") of DATA ("data=data"). X values are takes from the first
# column, which is the default.
plot = line_plot.T(label="/7TLB Misses", data=data_misses, ycol=1, tick_mark=tick_mark.star)
plot2 = line_plot.T(label="/7Directory Evictions", data=data_misses, ycol=2, tick_mark=tick_mark.square)

ar.add_plot(plot, plot2)

# The call to ar.draw() usually comes at the end of a program.  It
# draws the axes, the plots, and the legend (if any).

ar.draw()
