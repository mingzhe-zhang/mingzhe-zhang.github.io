
#
# Copyright (C) 2000-2005 by Yasushi Saito (yasushi.saito@gmail.com)
# 
# Pychart is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.
#
# Pychart is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
from pychart import *
theme.get_options()

# We have 10 sample points total.  The first value in each tuple is
# the X value, and subsequent values are Y values for different lines.


data = chart_data.read_str(', ',
"4KB, 1, 1.004, 1.205",
"64KB, 1, 1.002, 1.073",
"2MB, 1, 1.017, 1.019",
"64MB, 1, 1.444, 1.457",
"256MB, 1, 2.300, 2.310",
)

ar = area.T(y_range=(0.0,2.4),
            size=(180, 100),
            x_coord=category_coord.T(data, 0),
            y_grid_interval = 0.2,
            x_axis = axis.X(label="", format="/7/a-25{}%s"),
            y_axis = axis.Y(label="/8Execution Time Classification of \n Canneal Under Different Page Sizes", tic_interval=0.2, format="/7/a-0{}%1.1f"),
            legend=legend.T(nr_rows=3, loc=(15,75)), loc=(0,0))

plot1 = bar_plot.T(label="/7TLB Misses Induced", cluster=(0, 1), data = data, width=12, fill_style = fill_style.diag2_fine, hcol=3)
plot2 = bar_plot.T(label="/7Directory Evictions Induced", cluster=(0, 1), data = data, width=12, fill_style = fill_style.rdiag, hcol=2)
plot3 = bar_plot.T(label="/7Ideal TLBs and Directories", cluster=(0, 1), data = data, width=12, fill_style = fill_style.gray30, hcol=1)
ar.add_plot(plot1, plot2, plot3)


ar.draw()
