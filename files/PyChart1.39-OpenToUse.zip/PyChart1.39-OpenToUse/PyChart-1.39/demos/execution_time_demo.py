#
# Copyright (C) 2000-2005 by Yasushi Saito (yasushi.saito@gmail.com)
#
# Pychart is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.
#
# Pychart is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
from pychart import *
theme.get_options()



#data_4KB = chart_data.read_str(', ',
#"/9canneal, 1.0031, 1.0064, 1.0031, 1.0045, 1.0000, 0.0003, 0.0031, 0.0003, 0.0032, 0.0015",
#"/9fluidanimate, 0.9998, 1.0006, 0.9998, 1.0075, 1.0000, 0.0027, 0.0012, 0.0027, 0.0053, 0.0026",
#"/9streamcluster, 1.0104, 1.0109, 1.0104, 1.0072, 1.0000, 0.0099, 0.0040, 0.0099, 0.0014, 0.0092",
#"/9barnes, 1.0141, 1.0090, 1.0141, 1.0015, 1.0000, 0.0083, 0.0150, 0.0083, 0.0087, 0.0003",
#"/9fft, 0.9762, 0.9846, 0.9762, 0.9944, 1.0000, 0.0133, 0.0128, 0.0133, 0.0076, 0.0080",
#"/9ocean, 1.0027, 0.9976, 1.0027, 1.0016, 1.0000, 0.0003, 0.0091, 0.0003, 0.0096, 0.0056",
#"/9waterspt, 1.0228, 0.9946, 1.0228, 1.0055, 1.0000, 0.0144, 0.0088, 0.0144, 0.0108, 0.0110",
#"/9radix, 0.9998, 0.9996, 0.9998, 1.0019, 1.0000, 0.0008, 0.0003, 0.0008, 0.0002, 0.0002",
#"/9volrend, 0.9910, 0.9922, 0.9910, 1.0012, 1.0000, 0.0022, 0.0043, 0.0022, 0.0038, 0.0104",
#"/9lu, 1.0009, 1.0008, 1.0009, 1.0026, 1.0000, 0.0021, 0.0012, 0.0021, 0.0006, 0.0007",
#"/9GEOMEAN, 1.0010, 1.0003, 1.0010, 0.9982, 1.0000, 0.0011, 0.0015, 0.0011, 0.0002, 0.0038",
#"/9AVERAGE, 1.0020, 0.9997, 1.0020, 1.0024, 1.0000, 0.0050, 0.0056, 0.0050, 0.0047, 0.0048"
#)

data_4KB = chart_data.read_str(', ',
"/9canneal, 1.0026, 1.0089, 1.0479, 1.0005, 1.0000, 0.0032, 0.0053, 0.0028, 0.0128, 0.0044",
"/9fluidanimate, 1.1141, 1.0045, 1.1175, 1.0004, 1.0000, 0.0026, 0.0040, 0.0106, 0.0090, 0.0026",
"/9streamcluster, 1.0036, 1.0330, 1.1045, 1.0079, 1.0000, 0.0025, 0.0119, 0.0190, 0.0058, 0.0059",
"/9barnes, 1.0880, 1.0095, 1.0554, 1.0036, 1.0000, 0.0052, 0.0171, 0.0412, 0.0091, 0.0097",
"/9fft, 1.0022, 1.0053, 1.0188, 1.0005, 1.0000, 0.0010, 0.0028, 0.0011, 0.0003, 0.0012",
"/9ocean, 0.9995, 1.0019, 1.0976, 0.9993, 1.0000, 0.0013, 0.0008, 0.0042, 0.0016, 0.0007",
"/9waterspt, 0.9944, 1.0006, 1.0184, 0.9950, 1.0000, 0.0085, 0.0097, 0.0111, 0.0089, 0.0086",
"/9radix, 0.9822, 0.9872, 1.0104, 0.9892, 1.0000, 0.0017, 0.0105, 0.0136, 0.0164, 0.0156",
"/9volrend, 1.0095, 1.0056, 1.0141, 1.0012, 1.0000, 0.0057, 0.0029, 0.0021, 0.0008, 0.0013",
"/9lu, 1.0233, 1.0694, 1.1699, 1.0185, 1.0000, 0.0105, 0.0218, 0.0137, 0.0166, 0.0133",
"/9AVERAGE, 1.0219, 1.0126, 1.0655, 1.0016, 1.0000, 0.0042, 0.0087, 0.0119, 0.0081, 0.0063"
)



#data_256MB = chart_data.read_str(', ',
#"/9canneal, 1.0031, 1.0064, 1.0031, 1.0045, 1.0000, 0.0003, 0.0031, 0.0003, 0.0032, 0.0015",
#"/9fluidanimate, 0.9998, 1.0006, 0.9998, 1.0075, 1.0000, 0.0027, 0.0012, 0.0027, 0.0053, 0.0026",
#"/9streamcluster, 1.0104, 1.0109, 1.0104, 1.0072, 1.0000, 0.0099, 0.0040, 0.0099, 0.0014, 0.0092",
#"/9barnes, 1.0141, 1.0090, 1.0141, 1.0015, 1.0000, 0.0083, 0.0150, 0.0083, 0.0087, 0.0003",
#"/9fft, 0.9762, 0.9846, 0.9762, 0.9944, 1.0000, 0.0133, 0.0128, 0.0133, 0.0076, 0.0080",
#"/9ocean, 1.0027, 0.9976, 1.0027, 1.0016, 1.0000, 0.0003, 0.0091, 0.0003, 0.0096, 0.0056",
#"/9waterspt, 1.0228, 0.9946, 1.0228, 1.0055, 1.0000, 0.0144, 0.0088, 0.0144, 0.0108, 0.0110",
#"/9radix, 0.9998, 0.9996, 0.9998, 1.0019, 1.0000, 0.0008, 0.0003, 0.0008, 0.0002, 0.0002",
#"/9volrend, 0.9910, 0.9922, 0.9910, 1.0012, 1.0000, 0.0022, 0.0043, 0.0022, 0.0038, 0.0104",
#"/9lu, 1.0009, 1.0008, 1.0009, 1.0026, 1.0000, 0.0021, 0.0012, 0.0021, 0.0006, 0.0007",
#"/9AVERAGE, 1.0020, 0.9997, 1.0020, 1.0024, 1.0000, 0.0050, 0.0056, 0.0050, 0.0047, 0.0048"
#)



data_256MB = chart_data.read_str(', ',
"/9canneal, 2.2159, 2.0011, 1.9059, 1.1313, 1.0000, 0.0138, 0.0341, 0.0598, 0.0076, 0.0083",
"/9fluidanimate, 11.1452, 8.1845, 7.1299, 1.0319, 1.0000, 0.1278, 0.3725, 0.1182, 0.0078, 0.0068",
"/9streamcluster, 1.0602, 1.0358, 1.0988, 1.0310, 1.0000, 0.0026, 0.0048, 0.0128, 0.0069, 0.0036",
"/9barnes, 3.5327, 3.2832, 2.9485, 1.0464, 1.0000, 0.0826, 0.1027, 0.0261, 0.0125, 0.0123",
"/9fft, 1.1316, 1.0346, 1.0297, 1.0417, 1.0000, 0.0330, 0.0111, 0.0004, 0.0008, 0.0181",
"/9ocean, 1.0481, 1.0118, 1.0459, 1.0016, 1.0000, 0.0116, 0.0070, 0.0068, 0.0061, 0.0146",
"/9waterspt, 1.0155, 1.0046, 1.0268, 1.0047, 1.0000, 0.0059, 0.0082, 0.0083, 0.0060, 0.0059",
"/9radix, 7.1950, 7.1003, 6.6828, 1.0192, 1.0000, 0.0129, 0.0097, 0.0008, 0.0018, 0.0057",
"/9volrend, 3.5161, 3.0551, 2.9196, 1.0323, 1.0000, 0.1747, 0.1245, 0.1294, 0.0041, 0.0016",
"/9lu, 1.3474, 1.1410, 1.2478, 1.0824, 1.0000, 0.0260, 0.0247, 0.0243, 0.0202, 0.0184",
"/9AVERAGE, 3.3208, 2.8852, 2.7036, 1.0423, 1.0000, 0.0491, 0.0699, 0.0387, 0.0074, 0.0095"
)


ar = area.T(y_range=(0.9,1.21),
            size=(350, 90),
            x_coord=category_coord.T(data_4KB, 0),
            y_grid_interval = 0.05,
            x_axis = axis.X(label="", format="/a-25{}%s"),
            y_axis = axis.Y(label="/10Execution Time\nNormalized to cdsDir", tic_interval=0.1, format="/8/a-0{}%1.1f"),
            legend=legend.T(nr_rows=2, loc=(15,70)), loc=(0,0))

plot1 = bar_plot.T(label="/9spDir_small ", cluster=(0, 5), data = data_4KB, width=4.5, fill_style = fill_style.diag, hcol=1, error_bar = error_bar.bar2, error_minus_col=6, error_plus_col=6)
plot2 = bar_plot.T(label="/9spDir_mid ", cluster=(1, 5), data = data_4KB, width=4.5, fill_style = fill_style.rdiag2, hcol=2, error_bar = error_bar.bar2, error_minus_col=7, error_plus_col=7)
plot3 = bar_plot.T(label="/9spDir_large ", cluster=(2, 5), data = data_4KB, width=4.5, fill_style = fill_style.rdiag_fine, hcol=3, error_bar = error_bar.bar2, error_minus_col=8, error_plus_col=8)
plot4 = bar_plot.T(label="/9cuckooDir ", cluster=(3, 5), data = data_4KB, width=4.5, fill_style = fill_style.wave, hcol=4, error_bar = error_bar.bar2, error_minus_col=9, error_plus_col=9)
plot5 = bar_plot.T(label="/9cdsDir ", cluster=(4, 5), data = data_4KB, width=4.5, fill_style = fill_style.gray70, hcol=5, error_bar = error_bar.bar2, error_minus_col=10, error_plus_col=10)
ar.add_plot(plot1, plot2, plot3, plot4, plot5)

ar.draw()

ar = area.T(y_range=(0.9,1.21),
            size=(350, 90),
            x_coord=category_coord.T(data_256MB, 0),
            y_grid_interval = 0.05,
            x_axis = axis.X(label="", format="/a-25{}%s"),
            y_axis = axis.Y(label="", tic_interval=0.1, format="/8/a-0{}%1.1f"),
            legend=legend.T(nr_rows=2, loc=(15,70)), loc=(380,0))

plot1 = bar_plot.T(label="/9spDir_small ", cluster=(0, 5), data = data_256MB, width=4.5, fill_style = fill_style.diag, hcol=1, error_bar = error_bar.bar2, error_minus_col=6, error_plus_col=6)
plot2 = bar_plot.T(label="/9spDir_mid ", cluster=(1, 5), data = data_256MB, width=4.5, fill_style = fill_style.rdiag2, hcol=2, error_bar = error_bar.bar2, error_minus_col=7, error_plus_col=7)
plot3 = bar_plot.T(label="/9spDir_large  ", cluster=(2, 5), data = data_256MB, width=4.5, fill_style = fill_style.rdiag_fine, hcol=3, error_bar = error_bar.bar2, error_minus_col=8, error_plus_col=8)
plot4 = bar_plot.T(label="/9cuckooDir ", cluster=(3, 5), data = data_256MB, width=4.5, fill_style = fill_style.wave, hcol=4, error_bar = error_bar.bar2, error_minus_col=9, error_plus_col=9)
plot5 = bar_plot.T(label="/9cdsDir ", cluster=(4, 5), data = data_256MB, width=4.5, fill_style = fill_style.gray70, hcol=5, error_bar = error_bar.bar2, error_minus_col=10, error_plus_col=10)
ar.add_plot(plot1, plot2, plot3, plot4, plot5)

can = canvas.default_canvas()
#2.2159, 2.0011, 1.9059
can.show(392, 102, "/a50/8/hR2.22")
can.show(401, 102, "/a50/8/hR2.00")
can.show(410, 102, "/a50/8/hR1.91")
#11.1452, 8.1845, 7.1299
can.show(425, 103, "/a50/8/hR11.15")
can.show(433, 102, "/a50/8/hR8.18")
can.show(442, 102, "/a50/8/hR7.13")
#3.5327, 3.2832, 2.9485
can.show(485, 102, "/a50/8/hR3.53")
can.show(494, 102, "/a50/8/hR3.28")
can.show(503, 102, "/a50/8/hR2.95")
#7.1950, 7.1003, 6.6828
can.show(615, 102, "/a50/8/hR7.20")
can.show(624, 102, "/a50/8/hR7.10")
can.show(633, 102, "/a50/8/hR6.68")
#3.5161, 3.0551, 2.9196
can.show(645, 102, "/a50/8/hR3.52")
can.show(654, 102, "/a50/8/hR3.06")
can.show(663, 102, "/a50/8/hR2.92")
#1.3474, 1.1410, 1.2478
can.show(680, 102, "/a50/8/hR1.35")
can.show(693, 102, "/a50/8/hR1.25")
#3.3208, 2.8852, 2.7036
can.show(709, 102, "/a50/8/hR3.32")
can.show(718, 102, "/a50/8/hR2.89")
can.show(727, 102, "/a50/8/hR2.70")



#can = canvas.default_canvas()
#can.show(300, 175, "/10/hRDirectory Evictions under Different Directory Architectures")


#can = canvas.default_canvas()
can.show(220, 112, "/12/hR4KB Page Size")
can.show(610, 112, "/12/hR256MB Page Size")

ar.draw()
