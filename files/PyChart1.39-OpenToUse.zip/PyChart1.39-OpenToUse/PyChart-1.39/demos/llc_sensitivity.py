#
# Copyright (C) 2000-2005 by Yasushi Saito (yasushi.saito@gmail.com)
#
# Pychart is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.
#
# Pychart is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
from pychart import *
theme.get_options()


data = chart_data.read_str(', ',
"/6blackscholes, 1.0075, 1.0060, 0.9983, 1.0000, 0.0076, 0.0093, 0.0036, 0.0022",
"/6canneal, 2.6316, 2.4379, 2.1874, 1.0000, 0.0147, 0.0034, 0.0372, 0.0046",
"/6dedup, 1.1812, 1.0723, 1.0349, 1.0000, 0.0080, 0.0052, 0.0026, 0.0084",
"/6fluidanimate, 1.5102, 1.3832, 1.2285, 1.0000, 0.0134, 0.0179, 0.0495, 0.1399",
"/6streamcluster, 1.0737, 0.9956, 1.0007, 1.0000, 0.0056, 0.0038, 0.0045, 0.0106",
"/6x264, 1.0216, 1.0027, 1.0008, 1.0000, 0.0015, 0.0011, 0.0039, 0.0041",
"/6barnes, 1.8079, 1.5559, 1.0820, 1.0000, 0.0199, 0.0634, 0.0857, 0.0024",
"/6fft, 1.5390, 1.4920, 1.3938, 1.0000, 0.0034, 0.0022, 0.0055, 0.0016",
"/6ocean, 1.1671, 1.0366, 1.0061, 1.0000, 0.0139, 0.0042, 0.0043, 0.0029",
"/6volrend, 1.3229, 1.2565, 1.1469, 1.0000, 0.0218, 0.0033, 0.0039, 0.0035",
"/6waternsq, 1.0146, 0.9990, 1.0007, 1.0000, 0.0009, 0.0010, 0.0012, 0.0011",
"/6AVERAGE, 1.3888, 1.2943, 1.1891, 1.0000, 0.0101, 0.0104, 0.0184, 0.0165"
)

ar = area.T(y_range=(0.0,2.0),
            size=(300, 120),
            x_coord=category_coord.T(data, 0),
            x_axis = axis.X(label="", format="/a-340{}%s"),
            y_axis = axis.Y(label="/8Normalized Execution Time", tic_interval=0.2, format="/6/a-0{}%1.1f"),
            legend=legend.T(nr_rows=1, loc=(10,13)), loc=(0,45))

plot1 = bar_plot.T(label="/6 256KB LLC    ", cluster=(0, 4), data = data, width=5, fill_style = fill_style.gray20, hcol=1, error_bar = error_bar.bar2, error_minus_col=5, error_plus_col=5)
plot2 = bar_plot.T(label="/6 512KB LLC (Default Configuration)   ", cluster=(1, 4), data = data, width=5, fill_style = fill_style.gray50, hcol=2, error_bar = error_bar.bar2, error_minus_col=6, error_plus_col=6)
plot3 = bar_plot.T(label="/6 1024KB LLC    ", cluster=(2, 4), data = data, width=5, fill_style = fill_style.gray70, hcol=3, error_bar = error_bar.bar2, error_minus_col=7, error_plus_col=7)
plot4 = bar_plot.T(label="/6 Infinite LLC    ", cluster=(3, 4), data = data, width=5, fill_style = fill_style.gray90, hcol=4, error_bar = error_bar.bar2, error_minus_col=8, error_plus_col=8)
ar.add_plot(plot1, plot2, plot3, plot4)

can = canvas.default_canvas()
can.show(36, 172, "/a40/5/hR2.63")
can.show(42, 172, "/a40/5/hR2.44")
can.show(48, 172, "/a40/5/hR2.19")
can.show(250, 175, "/10/hRBenchmarks' Sensitivity to different LLC Size")

ar.draw()
