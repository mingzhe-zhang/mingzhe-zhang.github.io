#
# Copyright (C) 2000-2005 by Yasushi Saito (yasushi.saito@gmail.com)
#
# Pychart is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.
#
# Pychart is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
from pychart import *
theme.get_options()

#data = [(10, 20, 30, 5, 5, 2, 1), (20, 65, 33, 5, 5, 2, 1),
#        (30, 55, 30, 5, 5, 2, 1), (40, 45, 51, 7, 5, 2, 1), (50, 25, 27, 3, 5, 2, 1)]
data = chart_data.read_csv('stacked_clustered_errorbar.data', ',  ')
#fd = open("stacked_clustered_errorbar.data","r")
#data = chart_data.read_str(',', fd.readlines())
chart_object.set_defaults(area.T, size = (150, 120), y_range = (0, None),
                          x_coord = category_coord.T(data, 0))
chart_object.set_defaults(bar_plot.T, data = data)

ar = area.T(legend = legend.T(nr_rows=2, loc=(0,0)), loc=(0,80),
            x_axis=axis.X(label="X label", format="/a-30{}%d"),
            y_axis=axis.Y(label="Y label", tic_interval=10))
bar_plot.fill_styles.reset();
plot1 = bar_plot.T(label="data_read", cluster=(0, 2), fill_style = fill_style.gray50, hcol=1, error_bar = error_bar.bar2, error_minus_col=5, error_plus_col=5)
plot2 = bar_plot.T(label="coherence_read", cluster=(0, 2),  fill_style = fill_style.green, hcol=2, stack_on = plot1, error_bar = error_bar.bar2, error_minus_col=6, error_plus_col=6)
plot3 = bar_plot.T(label="data_write", cluster=(1, 2),  fill_style = fill_style.red, hcol=3, stack_on = None, error_bar = error_bar.bar2, error_minus_col=7, error_plus_col=7)
plot4 = bar_plot.T(label="date_write", cluster=(1, 2),  fill_style = fill_style.blue, hcol=4, stack_on = plot3, error_bar = error_bar.bar2, error_minus_col=8, error_plus_col=8)
ar.add_plot(plot1, plot2, plot3, plot4)
ar.draw()
